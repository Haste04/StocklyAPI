﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.DTOs
{
    public class InventoryDTO
    {
        public int Id { set; get; }
        public int ItemId { set; get; }
        public string ItemName { set; get; }
        public int Quantity { set; get; }
        public decimal Price { set; get; }
        public int PurchaseQuantity { set; get; }
        public InventoryDTO() { }
        public InventoryDTO(int id, string itemName, int quantity, decimal price)
        {
            Id = id;
            ItemName = itemName;
            Quantity = quantity;
            Price = price;
        }
    }
}
