﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Model;
using Core.DTOs;

namespace Core.Interfaces.Repository
{
    public interface ISalesDetailsRepository
    {
        public IEnumerable<SalesDetailsDTO> GetAll();
        public bool Add(SalesDetails salesDetails);

        IEnumerable<ReportDTO> GetAllReports();
        IEnumerable<ReportDTO> GetAllReportsByDates(DateTime start, DateTime end);

    }
}
