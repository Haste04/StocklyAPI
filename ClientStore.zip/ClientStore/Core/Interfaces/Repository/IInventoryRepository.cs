﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Model;
using Core.DTOs;

namespace Core.Interfaces.Repository
{
    public interface IInventoryRepository
    {
        IEnumerable<InventoryDTO> GetAll();
        bool AddQuantityByItemId(int itemId, int quantity);
        bool DeleteById(int id);
        bool UpdateQuantityById(int id, int quantity);
    }
}
