﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Model;

namespace Core.Interfaces.Repository
{
    public interface ISalesRepository
    {
        public int AddSales(decimal totalAmount);
        public bool UpdateTotalAmountById(int id, decimal totalAmount);

    }
}
