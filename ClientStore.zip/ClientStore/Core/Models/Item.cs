﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.DTOs;

namespace Core.Model
{
    public class Item 
    {
        public int Id { set;  get; }
        public String Name { set;  get; }
        public Decimal Price { set; get; }
        public int PurchasedQuantity { set; get; }
        public Item() { }
        public Item(int id, String name, Decimal price) 
        {
            Id = id;
            Name = name;
            Price = price;
        }
    }
}
