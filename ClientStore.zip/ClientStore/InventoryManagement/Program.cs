using ClientStore;
using Core.Interfaces.Repository;
using Infrastructure.Repositories;
using Core.Interfaces.Service;
using Infrastructure.Services;
using Infrastructure.Utilities;

namespace InventoryManagement
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.SetCompatibleTextRenderingDefault(false);

            // Manually create instances of services and repositories
            var itemRepository = new ItemRepository(Config.conStr);
            var inventoryRepository = new InventoryRepository(Config.conStr);
            var salesRepository = new SalesRepository(Config.conStr);
            var salesDetailsRepository = new SalesDetailsRepository(Config.conStr);

            var itemService = new ItemService(itemRepository);
            var inventoryService = new InventoryService(inventoryRepository);
            var salesService = new SalesService(salesRepository);
            var salesDetailsService = new SalesDetailsService(salesDetailsRepository);

            // Create AppServices manually
            var appServices = new AppServices(itemService, inventoryService, salesService, salesDetailsService);
            var stocklyForm = new Stockly(appServices);

            // Start the application with the Stockly form
            Application.Run(stocklyForm);
        }
    }
}
