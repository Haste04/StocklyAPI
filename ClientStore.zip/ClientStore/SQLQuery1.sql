﻿create database Test2;

use Test2;

create table Item (
	Id int primary key identity(1,1),
	Name varchar(255) not null, 
	Price decimal(10,2) not null check (Price >= 0) -- Prevent negative prices
);

create table Inventory (
	Id int primary key identity(1,1),
	ItemId int not null,
	Quantity int not null check (Quantity >= 0), -- Prevent negative quantities
	
	constraint Fk_Inventory_Item_ID foreign key (ItemID) references Item(ID) on delete cascade -- automatically delete item a if item a is deleted from Item table
);

create table Sales (
	Id int primary key identity(1,1),
SaleDate datetime default getDate(),
	TotalAmount decimal(10,2) default 0
);

create table SalesDetails (
	Id int primary key identity(1,1),
	ItemId int not null,
	SalesId int not null,
	QuantitySold int not null,
	SubTotal decimal(10,2) not null, -- quantity sold * Item(Price)
	
	constraint Fk_SaleDetails_Item_Id foreign key (ItemId) references Item(Id),
	constraint Fk_SalesDetails_Sales_Id foreign key (SalesId) references Sales(Id)
);

CREATE TRIGGER trg_DeleteInventoryWhenZero
ON Inventory
AFTER UPDATE
AS
BEGIN
    DELETE FROM Inventory
    WHERE Id IN (
        SELECT i.Id
        FROM Inventory i
        JOIN inserted ins ON i.Id = ins.Id
        WHERE i.Quantity = 0
    );
END;


